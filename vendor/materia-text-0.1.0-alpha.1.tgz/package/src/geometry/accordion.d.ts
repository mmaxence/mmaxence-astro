import type { Effect } from "../index.js";
export declare const accordion: Effect;
